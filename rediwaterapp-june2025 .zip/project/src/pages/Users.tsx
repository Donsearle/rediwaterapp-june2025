import React from 'react';
import { UserList } from '../components/Users/UserList';

export function Users() {
  return <UserList />;
}